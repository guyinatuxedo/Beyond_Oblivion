sdb
===

requires sdb to be installed.

apt-get install gcc g++
CFLAGS=-fPIC npm install sdb
